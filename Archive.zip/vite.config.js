/*
 * Vite config removed — this project is now API-only and does not use front-end tooling.
 * If you need to restore front-end builds, recreate `vite.config.js` with the necessary plugins and inputs.
 */

export default {};
