<html>

<body>
    <p>Hello,</p>
    <p>We received a request to reset your password. Click the link below to set a new password:</p>
    <p><a href="{{ $url }}">Reset password</a></p>
    <p>If you did not request this, you can safely ignore this message.</p>
</body>

</html>