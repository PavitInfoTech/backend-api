<html>

<body>
    <p>Hello,</p>
    <p>Click the link below to verify your email address and continue:</p>
    <p><a href="{{ $callback }}">Verify email</a></p>
    <p>After verification you'll be redirected to the application UI.</p>
</body>

</html>