<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Run Migrations</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <h1>Run Migrations</h1>

    <form method="POST" action="/run-mig">
        <?php echo csrf_field(); ?>
        <button type="submit">Run Migrations</button>
    </form>

    <hr />

    <p>If you are running this from a remote script or cPanel, use:</p>
    <pre>curl -X POST -H "X-RUN-MIG-TOKEN: &lt;SECRET&gt;" https://your-domain/run-mig</pre>

</body>
</html>
<?php /**PATH /Users/chathura/Documents/GitHub/temp/backend-api/resources/views/run-mig-run.blade.php ENDPATH**/ ?>